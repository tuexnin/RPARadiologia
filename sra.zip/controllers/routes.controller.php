<?php

class RoutesController{

    public function main(){
        include "pages/main.php";
    }

    public function login(){
        include "login/login.php";
    }
}